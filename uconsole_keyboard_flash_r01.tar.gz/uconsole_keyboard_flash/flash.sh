#!/bin/bash

sudo  ./maple_upload ttyACM0 2 1EAF:0003  uconsole_keyboard.ino.bin
